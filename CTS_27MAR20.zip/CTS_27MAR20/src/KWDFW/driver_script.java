package KWDFW;

import org.openqa.selenium.WebDriver;

public class driver_script {
	public static void main(String[] args) {
		String kw,loc,td;
		WebDriver dr = null;
		all_webelement_fns we = new all_webelement_fns(dr);
		excel_operations excel = new excel_operations();
		for(int r=1;r<=5;r++)
		{
			kw = excel.read_excel(r,3);
			loc = excel.read_excel(r,4);
			td = excel.read_excel(r,5);
			switch(kw)
			{
			case "launchBrowser":
				we.launchChrome(td);
				break;
				
			case "enterText" :
				 we.enter_txt(loc, td);
				 break;
				 
				 
			case "click" :
				we.click(loc);
				break;
			
			}
		}
	}

}
