package KWDFW;

public class test1 {

	public static void main(String[] args) {
        write_operations excel = new write_operations();
        
        excel.write_excel(0, 0, "selenium");
        excel.write_excel(1, 2, "selenium");
        excel.write_excel(4, 4, "selenium");
        
        
		

	}

}
