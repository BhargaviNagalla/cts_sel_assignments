package KWDFW;

public class test2 {

	public static void main(String[] args) {
        write_operations2 excel = new write_operations2();
        
        excel.write_excel1(0, 0, "selenium");
        excel.write_excel2(1, 2, "switch");
        excel.write_excel3(4, 4, "excel");
        
        
		

	}

}
