package dataproviders2;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataprovider_login {
	
	basic_testlogin2 test;
	 @Test(dataProvider="login_data")
	  
	  public void login(String eid,String pwd,String exp_eid) {
		 
		 test = new basic_testlogin2();
		 String a_eid = test.login(eid, pwd);
		 SoftAssert sa = new SoftAssert();
		 sa.assertEquals(a_eid, exp_eid);
		 sa.assertAll();
		  //System.out.println("email id :"+eid+ "pwd : "+pwd);
		  
	  }
	  @DataProvider(name="login_data")
	  public String[][] provide_data()
	  {
		  String[][] data = {
				  {"nagallabhargavi129@gmail.com","chinni@12","nagallabhargavi129@gmail.com"},
			
				  {"nagallabhargavi129@gmail.com","chinni@12","nagallabhargavi121@gmail.com"}
				       
		  } ;
		  return data;
	  }
	}