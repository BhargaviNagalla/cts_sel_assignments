package data_providers;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataproviders_login {
	basic_testlogin test;
  @Test(dataProvider="login_data")
  public void logintest(String eid,String pwd,String exp_eid)
  {
	  test = new basic_testlogin();
	  String a_eid = test.login(eid,pwd);
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(a_eid, exp_eid);
	  sa.assertAll();
	  }
  @DataProvider(name="login_data")
  public String[][] provide_data(){
	   String[][] data = { 
			   {"nagallabhargavi129@gmail.com","chinni@12","nagallabhargavi129@gmail.com"},
			   {"nagallabhargavi129@gmail.com","chinni@12","nagallabhargavi121@gmail.com"}
	   };
	return data;
  }
}
