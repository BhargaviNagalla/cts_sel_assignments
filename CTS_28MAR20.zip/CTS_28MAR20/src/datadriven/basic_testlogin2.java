package datadriven;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class basic_testlogin2 {


	public static String login(String uid,String pwd)
	{
		
		String a_result;
		System.setProperty("Webdriver.chrome.driver","chromedriver.exe");
		WebDriver driver = new ChromeDriver();
				driver.get("http://demowebshop.tricentis.com/login");
				driver.findElement(By.xpath("//input[@class='email']")).sendKeys(uid);
				driver.findElement(By.xpath("//input[@class='password']")).sendKeys(pwd);
				driver.findElement(By.xpath("//input[@value='Log in']")).click(); 
				String a_eid = driver.findElement(By.xpath("//div[@class='header-links']//child::li[1]/a")).getText();
				driver.close();
				return a_eid;
				

	}

}



