package com.baseclass;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class utilities {
	static int counter=1;
	WebDriver dr;
	Logger log;
	public utilities(WebDriver dr)
	{
		this.dr=dr;
		log = Logger.getLogger("devpinoyLogger");
		
	}
	
	public static WebDriver launch_browser(String browser ,String url)
	{
		WebDriver dr =null;
		String ch_driver_path="chromedriver.exe";
		String ff_driver_path="src\\test\\resources\\DRIVER\\geckodriver_v0.26.exe";
		switch(browser)
		{
		case "chrome":
			System.setProperty("webdriver.chrome.driver",ch_driver_path);
			dr = new ChromeDriver();
			break;
		case "firefox":
			
			System.setProperty("webdriver.gecko.driver","geckodriver_v0.26.exe");
			dr = new FirefoxDriver();
			break;
			default:
				System.out.println("Supported Browser Options : chrome & firefox");
				break;
		}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return dr;
		
		
	}
	

}
