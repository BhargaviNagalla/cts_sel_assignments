package com.tests;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.baseclass.utilities;
import com.excel.util.excel_io_arr;
import com.pages.Productspage;
import com.pages.homepage;
import com.pages.pagelogin;


public class test1 extends excel_io_arr {
             
			WebDriver dr;
		    pagelogin pl;
		    Productspage pp;
		    //homepage hp;
		    @BeforeMethod
			  public void launch_Browser() 
			  {
				  
				  dr=utilities.launch_browser("chrome", "https://www.saucedemo.com/");
					pl = new pagelogin(dr);
				
					pp=new Productspage(dr);
 }
		    @BeforeClass
		    public void get_data()
		    {
		    	get_test_data();
		    }
		    @DataProvider(name="login_data")
			  public String[][] provide_data(){
				  return testdata;
			  }
//		    @Test
//		    public void title()
//		    {
//		    	String actual=pp.verify_title();
//		    	String Expected ="Swag Labs";
//		    	Assert.assertEquals(actual, Expected);
//		    }
//		   
		    @Test(dataProvider="login_data") 
			 
			  public void logintest2(String username,String password,String exp_res) {
			
				String act_pro;
				pl.do_login(username, password);
				pp.verify_title();
				act_pro=pp.get_text();
				
				
				
				System.out.println(act_pro);
				Assert.assertEquals(act_pro, exp_res);
				
					 
				}
		    @AfterMethod
		    public void afterMethod()
		    {
		    	dr.quit();
		    	
		    }
			 
			 
		   
		   
		   
		  
		 
		 
		 
		
		 
		
		 
		  
  }
		

