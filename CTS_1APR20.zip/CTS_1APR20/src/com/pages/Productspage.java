package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Productspage {
	WebDriver dr3;
	By login_link =By.linkText("Log in");
	By txt = new By.ByClassName("product_label");
	public Productspage(WebDriver dr)
	{
		this.dr3=dr;
	}
	public String verify_title() {
		String str=dr3.getTitle();
		
		return str;
	}
public String get_text() {
	String act_pro=dr3.findElement(txt).getText();
	
	return act_pro;
}
}
