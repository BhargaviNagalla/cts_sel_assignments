package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class homepage {
	WebDriver dr1;
	By login_link = By.linkText("Log in");
	By register_link = By.linkText("Register");
	
	
	public homepage(WebDriver dr)
	{
		this.dr1=dr;
	}
	public void click_register_link()
	{
		dr1.findElement(register_link).click();
	}
	public void click_login_link()
	{
		dr1.findElement(login_link).click();
	}
	//public void verify_title() {
		//String title=dr1.getTitle();
		//String act_res = dr2.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]")).getText();
		//if(title.equals("swaglabs"))
			//System.out.println("title matches");
		//else
			//System.out.println("title does not match");
	//}
//	public String get_titlename()
//	{
//	  String title= dr1.getTitle();
//	 return title;
//	}
}
