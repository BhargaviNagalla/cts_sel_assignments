package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
public class pagelogin {
WebDriver dr2;
	@FindBy(id="user-name")
	WebElement uid;
	@FindBy(id="password")
	WebElement pwd;
	@FindBy(id="login_credentials")
	WebElement prd;
	@FindBy(className="btn_action")
	WebElement log_btn;
public pagelogin(WebDriver dr)
{
	this.dr2=dr;
	PageFactory.initElements(dr, this);
}
public void enter_User_id(String username)
{
	uid.sendKeys(username);
}
public void enter_password(String password)
{
	pwd.sendKeys(password);
}
public void click_login_btn()
{
	log_btn.click();
	
}
//public void verify_product()
//{
	//String product = dr2.findElement(By.xpath("//*[@id=\"inventory_filter_container\"]/div")).getText();
	//if(product.equals("Products"))
//System.out.println("product matches");
	//else
		//System.out.println("product doesnt matches");

//}
//public String get_verifyproduct()
//{
//	String pname=dr2.findElement(xp_productname).getText();
//	return pname;
//}


public String do_login(String username, String password)
{
this.enter_User_id(username);
this.enter_password(password);
this.click_login_btn();
return username;

}
public void successful_login() {
	System.out.println("Log in successful");
}

}