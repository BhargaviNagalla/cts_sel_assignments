package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class test1 {
	public static WebDriver dr;
	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("Log in page is displayed");;

	System.setProperty("Webdriver.chrome.driver","chromedriver.exe");
	dr = new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com/login");

}
	@When("^User enters login data and clicks ok button$")
	public void user_enters_login_data_and_clicks_ok_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("nagallabhargavi129@gmail.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("chinni@12");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click(); 
	}
	@Then("^Home page is displayed$")
	public void home_page_is_displayed() throws Throwable {
		
	    // Write code here that turns the phrase above into concrete actions
		//String product = dr.findElement(By.xpath("//*[@id=\"inventory_filter_container\"]/div")).getText();
		String a_email = dr.findElement(By.xpath("//div[@class='header-links']//child::li[1]/a")).getText();
	SoftAssert sa = new SoftAssert();
	sa.assertEquals(a_email, "nagallabhargavi129@gmail.com");
	sa.assertAll();
	dr.close();
		 
	}
	
	@When("^User enters INVALID email id, valid pwd and clicks ok button$")
	public void user_enters_INVALID_email_id_valid_pwd_and_clicks_ok_button() throws Throwable {
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("nagallabhargavi128@gmail.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("chinni@12");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click(); 
	}
	@Then("^Login page is displayed with err msg - No customer account found$")
	public void login_page_is_displayed_with_err_msg_No_customer_account_found() throws Throwable {
		String msg = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
		System.out.println(msg);
		dr.quit();
	}

}

