package com.stepdefination;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.baseclass.library;
import com.pages.orangehrmlogin;
import com.pages.orangehrmrecruitment;
import com.pages.orangehrradmin;
import com.seleniumutil.seleniumutil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class orangehrmrecruitmentstep extends library{
	
	seleniumutil  util;
	orangehrmrecruitment recruit;
	orangehrmlogin login;
	Logger LOG = Logger.getLogger(orangehrradmin.class.getName());


	@Given("^launch the orangehrm appliction$")
	public void launch_the_orangehrm_appliction() throws IOException  {
		
    launchApp();
	}

	@Then("^click on the recruitment")
	public void click_on_the_recruitment() {

		login = new orangehrmlogin(driver);
	    driver.findElement(By.id("txtUsername")).sendKeys("Admin");
	    login.orangehrm_password("admin123");
	    login.orangehrm_loginbtn();
	    
		recruit = new orangehrmrecruitment(driver);
		recruit.recruitmentclick();
		
	}

	@Then("^search with name and click search button$")
	public void search_with_name_and_click_search_button()  {
		recruit = new orangehrmrecruitment(driver);
		recruit.jobtitle();
		
	    util = new seleniumutil(driver);
	    util.takeSnapShot("C:\\Users\\User\\eclipse-workspace\\CUCUMBERHYBRIDFRAMEWORK\\src\\test\\resources\\screenshots\\recruit.png");
	}


}
