package com.stepdefination;

import java.io.IOException;

import com.baseclass.library;
import com.pages.orangehrmlogin;
import com.seleniumutil.seleniumutil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class orangehrmloginstep extends library {
	 
	  orangehrmlogin login;

	  seleniumutil  util;
	    
		@Given("^launch the broswer and enter the url$")
		public void launch_the_broswer_and_enter_the_url() throws IOException {
	    	
	    	launchApp();
		   	}
		
		@When("^login page is opened$")
		public void login_page_is_opened()  {
		    
			util = new seleniumutil(driver);
			util.takeSnapShot("C:\\Users\\User\\eclipse-workspace\\CUCUMBERHYBRIDFRAMEWORK\\src\\test\\resources\\screenshots\\login.png");
			
			
		}
		
		@Then("^enter the \"([^\"]*)\" and \"([^\\\"]*)\"$")
		public void enter_the_username_and_password(String username1, String password1) {
			login = new  orangehrmlogin(driver);
			login.orangehrm_username(username1);
			login.orangehrm_password(password1);
		}
		

		@Then("^click the login button$")
		public void click_the_login_button()  {
		login = new  orangehrmlogin(driver);
		   login.orangehrm_loginbtn();
		}

}
