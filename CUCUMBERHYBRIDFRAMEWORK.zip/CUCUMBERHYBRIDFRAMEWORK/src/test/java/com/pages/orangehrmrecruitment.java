package com.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class orangehrmrecruitment {
	WebDriver driver;
	By recruitment = By.xpath("//*[@id=\"menu_recruitment_viewRecruitmentModule\"]/b");
	By jobtitle = By.xpath("//*[@id=\"candidateSearch_jobTitle\"]");
	By jtitle=By.xpath("//*[@id=\"candidateSearch_jobTitle\"]");
	By candidatename=By.xpath("//*[@id=\"candidateSearch_candidateName\"]");
	By searchbutton = By.xpath("//*[@id=\"btnSrch\"]");
	Logger LOG =  Logger.getLogger(orangehrmrecruitment.class.getName());
	orangehrmlogin login;
	
	public orangehrmrecruitment(WebDriver driver) {
		 this.driver= driver;
	}
	
	//click the Driectory menu
	public void recruitmentclick() {
		
		driver.findElement(recruitment).click();
		LOG.info("recruitment is clicked");
	}
public void jobtitle() {
		
		driver.findElement(jobtitle).click();
		driver.findElement(jtitle).click();
		LOG.info("jobtitle is clicked");
	}
public void candidatename() {
	
	driver.findElement(candidatename).sendKeys("Programmer Analyst Trainee (PAT)");
	LOG.info("candidatename is clicked");
}

	
	//Searching and click on search button
	public void  search() {
		driver.findElement(searchbutton).click();
		LOG.info("Search button is clicked");
	}

}
