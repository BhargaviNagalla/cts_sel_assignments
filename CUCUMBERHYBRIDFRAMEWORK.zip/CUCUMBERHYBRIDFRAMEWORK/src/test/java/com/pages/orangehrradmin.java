package com.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class orangehrradmin {
	WebDriver driver;
	By admin = By.xpath("/html/body/div[1]/div[2]/ul/li[1]/a/b");
	By searchdirectory = By.xpath("//*[@id=\"searchSystemUser_userName\"]");
	By searchbutton = By.xpath("//*[@id=\"searchBtn\"]");
	Logger LOG = Logger.getLogger(orangehrradmin.class.getName());
	orangehrradmin login;
	
	public orangehrradmin(WebDriver driver) {
		this.driver=driver;
	}
	
	//To click the admin menu
	public void To_clickAdminbutton() {
				
		driver.findElement(admin).click();
		LOG.info(" Admin in clicked");
	
	}
			
	//To click the jobtitle in the job menu 
	public void to_click_search(String name) {
		driver.findElement(searchdirectory).sendKeys(name);
		
	
		LOG.info("Name is entered in the text box");
		driver.findElement(searchbutton).click();
		LOG.info("Search button is clicked");
		
	}
	
	

}
