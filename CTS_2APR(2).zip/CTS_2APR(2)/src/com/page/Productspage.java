package com.page;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Productspage {
	WebDriver dr3;
	By cart_btn = By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button");
	By login_link =By.linkText("Log in");
	By txt = new By.ByClassName("product_label");
	By prod=new By.ByClassName("inventory_details_name");
	By price=new By.ByClassName("inventory_details_price");
	
	public Productspage(WebDriver dr)
	{
		this.dr3=dr;
	}
	public void click_addcart_btn()
	{
		dr3.findElement(cart_btn).click();
		
	}
	public String verify_title() {
		String str=dr3.getTitle();
		
		return str;
	}
public String get_text() {
	String act_pro=dr3.findElement(txt).getText();
	
	return act_pro;
	}
	public String get_product() {
		String st=dr3.findElement(prod).getText();
		return st;
				
	}
	public String get_price() {
		String st1=dr3.findElement(price).getText();
		return st1;
}

}
