package com.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class cartpage {
WebDriver dr4;

@FindBy(className="fa-layers-counter shopping_cart_badge")
WebElement cartlib;
By expprod=new By.ByClassName("inventory_item_name");
By expprice=new By.ByClassName("inventory_item_price");
public cartpage(WebDriver dr)
{
	this.dr4=dr;
}
public void click_cartlib_btn()
{
	cartlib.click();
	
	
}
public String get_expproduct() {
	String st2=dr4.findElement(expprod).getText();
	return st2;
			
}
public String get_expprice() {
	String st3=dr4.findElement(expprice).getText();
	return st3;
}


}
