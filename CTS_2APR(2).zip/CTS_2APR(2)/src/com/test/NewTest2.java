package com.test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.page.Productspage;
import com.page.cartpage;

public class NewTest2 {
	WebDriver dr;
	Productspage pp;
	cartpage cp;
	
  @Test
  public void verifyprod() {
	  String act_name=pp.get_product();
	  String exp_name=cp.get_expproduct();
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(act_name, exp_name);
  }@Test
  public void verifyprodprice() {
	  String act_price=pp.get_price();
	  String exp_price=cp.get_expprice();
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(act_price, exp_price);
  }
  
}
