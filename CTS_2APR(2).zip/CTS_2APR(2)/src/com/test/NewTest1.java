package com.test;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.base.utilities;
import com.excel.excel_io_arr;
import com.page.Productspage;
import com.page.cartpage;
import com.page.pagelogin;


public class NewTest1 extends excel_io_arr{
    
	WebDriver dr;
   pagelogin pl;
   Productspage pp;
   cartpage cp;
   String username ="standard_user", password="secret_sauce";
		   String exp_res="Products";
   //homepage hp;
   @BeforeMethod
	  public void launch_Browser() 
	  {
		  
		  dr=utilities.launch_browser("chrome", "https://www.saucedemo.com/");
			pl = new pagelogin(dr);
		
			pp=new Productspage(dr);
			cp=new cartpage(dr);
}
   @BeforeClass
   public void get_data()
   {
   	get_test_data();
   }
  // @DataProvider(name="login_data")
	  public String[][] provide_data(){
		  return testdata;
	  }
//   @Test
//   public void title()
//   {
//   	String actual=pp.verify_title();
//   	String Expected ="Swag Labs";
//   	Assert.assertEquals(actual, Expected);
//   }
//  
  // @Test(dataProvider="login_data") 
	 @Test
	  public void logintest2() {
	
		String act_pro;
		pl.do_login("standard_user","secret_sauce");
		pp.verify_title();
		String act_name=pp.get_product();
	 	  String exp_name=cp.get_expproduct();
	 	  SoftAssert sa=new SoftAssert();
	 	  sa.assertEquals(act_name, exp_name);
	 	 String act_price=pp.get_price();
	 	  String exp_price=cp.get_expprice();
	 	  
	 	  sa.assertEquals(act_price, exp_price);
		
			 
		}
   @AfterMethod
   public void afterMethod()
   {
   	dr.quit();
   	
   }
}
	 
	 
