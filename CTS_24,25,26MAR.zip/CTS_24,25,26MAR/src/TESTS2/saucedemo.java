package TESTS2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import PAGES2.homepage2;
import PAGES2.page_login;

public class saucedemo {
              page_login web;
			WebDriver dr;
		    page_login pl;
		    homepage2 hp;
			
		  @BeforeClass
		  public void launchbrowser() 
		  {
			  System.setProperty("Webdriver.chrome.driver","chromedriver.exe");
				dr = new ChromeDriver(); 
				dr.get("https://www.saucedemo.com/");
				pl = new page_login(dr);
				hp= new homepage2(dr);

			  
		  }
		  @Test
		  public void logintest1() {
			  String exp_res = "Swag Labs",act_res,actual,expected="Products";
			  
			  pl.click_login_btn();
				
				 pl.do_login("standard_user", "secret_sauce");
				 act_res=hp.get_titlename();
				 actual=pl.get_verifyproduct();
				 Assert.assertEquals(act_res, exp_res);
				 Assert.assertEquals(actual, expected);
				 System.out.println("act_res : " + act_res);
				 System.out.println("actual : " + actual);
			
			 
			  
			  
		  }
		  
  }

