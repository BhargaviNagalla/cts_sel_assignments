package PAGES2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class page_login {
WebDriver dr2;
	By usname = By.id("user-name");
	By pwd = By.id("password");
	By login_btn=By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]");
	By xp_productname = By.xpath("//*[@id=\"inventory_filter_container\"]/div");
public page_login(WebDriver dr)
{
	this.dr2=dr;
}
public void enter_User_id(String username)
{
	dr2.findElement(usname).sendKeys(username);
}
public void enter_password(String password)
{
	dr2.findElement(pwd).sendKeys(password);
}
public void click_login_btn()
{
	dr2.findElement(login_btn).click();
	
}
//public void verify_product()
//{
	//String product = dr2.findElement(By.xpath("//*[@id=\"inventory_filter_container\"]/div")).getText();
	//if(product.equals("Products"))
//System.out.println("product matches");
	//else
		//System.out.println("product doesnt matches");
//}
public String get_verifyproduct()
{
	String pname=dr2.findElement(xp_productname).getText();
	return pname;
}
public void do_login(String username, String password)
{
this.enter_User_id(username);
this.enter_password(password);
this.click_login_btn();
//this.verify_product();
}
}