package com.cts.demo;

import org.testng.Assert;
import org.testng.annotations.Test;

public class NewTest1 {
  logintestcase demoweb;
  @Test
  public void test1() {
	  String act_res;
	  String exp_res = "nagallabhargavi129@gmail.com";
	  demoweb = new logintestcase();
	  act_res = demoweb.login();
	  Assert.assertEquals(act_res, exp_res);
  }
}
