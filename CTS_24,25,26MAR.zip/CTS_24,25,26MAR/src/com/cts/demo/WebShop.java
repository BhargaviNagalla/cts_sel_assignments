package com.cts.demo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class WebShop {
	public WebDriver driver;
	@Test

	public void login() {
		
		
		driver.get("http://demowebshop.tricentis.com/");
		driver.findElement(By.className("ico-login")).click();
		driver.findElement(By.id("Email")).sendKeys("nagallabhargavi129@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("chinni@12");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		String Actual = driver.getTitle();
		String Expected = driver.getTitle();
		if(Actual.equals(Expected))
		{
			System.out.println("Test Passed");
		}else {
			System.out.println("Test failed");
		}

	}
	@BeforeMethod
	public void beforeMethod() {
		System.setProperty("Webdriver.chrome.driver","chromedriver.exe");
		 driver = new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	}
	@AfterMethod
	public void afterMethod()
	{
		driver.quit();
	}

}
