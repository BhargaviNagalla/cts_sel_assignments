package TESTS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import PAGES.HOME_PAGE;
import PAGES.LOGIN_PAGE;

public class newtest1 {
	WebDriver dr;
	HOME_PAGE hp;
	LOGIN_PAGE lp;
	
  @BeforeClass
  public void launchbrowser() 
  {
	  System.setProperty("Webdriver.chrome.driver","chromedriver.exe");
		dr = new ChromeDriver(); 
		dr.get("http://demowebshop.tricentis.com/");
		hp = new HOME_PAGE(dr);
		lp = new LOGIN_PAGE(dr);
	  
  }
  @Test
  public void logintest1() {
	  hp.click_login_link();
	  lp.do_login("nagallabhargavi129@gmail.com", "chinni@12");
  }
  
}
