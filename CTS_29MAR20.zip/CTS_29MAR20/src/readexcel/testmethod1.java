package readexcel;

public class testmethod1 {
	



		public static void main(String[] args) {
	        readdata excel = new readdata();
	        
	        String a=excel.read_excel(0,0);
	        String b=excel.read_excel(1,0);
	        String c=excel.read_excel(4,4);
	        
	        System.out.println(a);
	        System.out.println(b);
	        System.out.println(c);
	        

		}

	}



