package writeoperations;

import writeoperations.testmethod;

public class testmethod {

	public static void main(String[] args) {
        webelement excel = new webelement();
        
        excel.write_excel(0, 0, "Bhargavi");
        excel.write_excel(2, 2, "Nagalla");
        excel.write_excel(4, 4, "Cognizant");
        

        }

}

