package assign;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login {
	public String login(String uid,String pwd)
	{
		
		System.setProperty("Webdriver.chrome.driver","chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://jpetstore.cfapps.io/login");
		//driver.findElement(By.xpath("//*[@id=\"Content\"]/p[1]/a")).click();
		//driver.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[2]")).click();
		driver.findElement(By.xpath("//*[@id=\"Catalog\"]/form/p[2]/input[1]")).sendKeys(uid);
		driver.findElement(By.xpath("//*[@id=\"Catalog\"]/form/p[2]/input[2]")).sendKeys(pwd);
	
				
		driver.findElement(By.xpath("//*[@id=\"login\"]")).click();
		String actualuid=driver.findElement(By.xpath("//*[@id=\"WelcomeContent\"]/div/span")).getText();
		driver.close();
		return actualuid;
		
				

	}


}
