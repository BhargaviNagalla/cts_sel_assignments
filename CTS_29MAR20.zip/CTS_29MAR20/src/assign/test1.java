package assign;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


 

	  public class test1 extends excel{
			login test;
		  @BeforeClass
		  public void get_data() 
		  {
			 get_test_data();
		  }
		  @Test(dataProvider="login_data")
		  public void logintest(String uid,String pwd,String exp_eid)
		  {
			 test = new login() ;
			 String actualuid = test.login(uid,pwd);
			 SoftAssert sa = new SoftAssert();
			 sa.assertEquals(actualuid,exp_eid);
			 sa.assertAll();
			}
		  @DataProvider(name="login_data")
		  public String[][] provide_data(){
		 
				   
		  return testdata;
		  
		}
		
  }

